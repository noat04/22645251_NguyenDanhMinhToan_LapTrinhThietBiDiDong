package com.example.employee_rest_api.web;


import com.example.employee_rest_api.model.Employee;
import com.example.employee_rest_api.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = { "http://localhost:19006", "http://localhost:5173", "http://127.0.0.1:19006" }, allowCredentials = "false")
public class EmployeeController {
  private final EmployeeService service;
  public EmployeeController(EmployeeService service){ this.service = service; }

  @GetMapping public List<Employee> all(){ return service.findAll(); }

  @GetMapping("/{id}") public Employee one(@PathVariable Long id){ return service.findById(id); }

  @PostMapping public Employee create(@Valid @RequestBody Employee e){ return service.create(e); }

  @PutMapping("/{id}") public Employee update(@PathVariable Long id, @Valid @RequestBody Employee e){ return service.update(id, e); }

  @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}

