package com.example.employee_rest_api;


import com.example.employee_rest_api.model.Employee;
import com.example.employee_rest_api.repo.EmployeeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.math.BigDecimal;

@Configuration
public class Bootstrap {
  @Bean CommandLineRunner seed(EmployeeRepository repo){
    return args -> {
      if(repo.count()==0){
        repo.save(new Employee(null,"Alice","alice@example.com",new BigDecimal("1000"),"IT"));
        repo.save(new Employee(null,"Bob","bob@example.com",new BigDecimal("900"),"HR"));
      }
    };
  }
}
