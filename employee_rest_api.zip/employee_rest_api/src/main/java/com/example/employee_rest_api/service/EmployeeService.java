package com.example.employee_rest_api.service;

import com.example.employee_rest_api.model.Employee;
import java.util.List;

public interface EmployeeService {
  List<Employee> findAll();
  Employee findById(Long id);
  Employee create(Employee e);
  Employee update(Long id, Employee e);
  void delete(Long id);
}
