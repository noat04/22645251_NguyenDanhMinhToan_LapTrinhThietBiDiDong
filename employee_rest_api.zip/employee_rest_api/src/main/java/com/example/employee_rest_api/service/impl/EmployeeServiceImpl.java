package com.example.employee_rest_api.service.impl;


import com.example.employee_rest_api.model.Employee;
import com.example.employee_rest_api.repo.EmployeeRepository;
import com.example.employee_rest_api.service.EmployeeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
  private final EmployeeRepository repo;
  public EmployeeServiceImpl(EmployeeRepository repo){ this.repo = repo; }

  @Override public java.util.List<Employee> findAll(){ return repo.findAll(); }

  @Override public Employee findById(Long id){
    return repo.findById(id).orElseThrow(() -> new RuntimeException("Employee not found: " + id));
  }

  @Override public Employee create(Employee e){ e.setId(null); return repo.save(e); }

  @Override public Employee update(Long id, Employee e){
    Employee cur = findById(id);
    cur.setName(e.getName());
    cur.setEmail(e.getEmail());
    cur.setSalary(e.getSalary());
    cur.setDepartment(e.getDepartment());
    return repo.save(cur);
  }

  @Override public void delete(Long id){ repo.deleteById(id); }
}

