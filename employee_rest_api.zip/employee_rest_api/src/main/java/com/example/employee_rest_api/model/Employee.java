package com.example.employee_rest_api.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)   // required by JPA
@AllArgsConstructor                                  // optional convenience
@Entity
@Table(name = "employees")
public class Employee {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotBlank
  @Size(max = 100)
  private String name;

  @Email
  @NotBlank
  @Size(max = 120)
  @Column(unique = true)
  private String email;

  @NotNull
  @DecimalMin("0.0")
  @Digits(integer = 12, fraction = 2)
  private BigDecimal salary;

  @Size(max = 60)
  private String department;
}
